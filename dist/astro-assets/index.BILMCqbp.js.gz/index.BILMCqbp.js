import{c as n}from"./Admonition.B1kDTFi5.js";import{F as s,$ as r}from"./keystatic-page.D64z8aiI.js";import"./___vite-browser-external_commonjs-proxy.B2SwpVhP.js";import"./_commonjsHelpers.C4iS2aBk.js";import"./index.zSnisxZ3.js";/* empty css                               */import"./astro/assets-service.CJMMCYvq.js";const l={title:"Website Online",description:"My first personal website!",draft:!1,authors:["gxjansen"],pubDate:"2001-02-08T00:00:00.000Z",heroImage:"../website-online/heroImage.png",categories:["Archive","Website Update"]};function b(){return[]}const f=!0;function o(t){const e={br:"br",em:"em",hr:"hr",li:"li",p:"p",ul:"ul",...t.components};return n(s,{children:[n(e.p,{children:n(e.em,{children:"Translated from the original Dutch (below), posted on guidojansen.nl by my classmate that had setup the site:"})}),`
`,n(e.p,{children:"A smooth site for a fast swimmer. That’s our intention. Through this site, Guido will keep you informed about competitions, trainings, and interesting facts, and we’re far from finished building it!!!!"}),`
`,n(e.ul,{children:[`
`,n(e.li,{children:[`
`,n(e.p,{children:"Lots of photos"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"Latest news"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"Guestbook"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"English version"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"etc., etc."}),`
`]}),`
`]}),`
`,n(e.p,{children:["So keep an eye on this site!!!",n(e.br,{}),`
We wish Guido lots of success with the Dutch championships.`]}),`
`,n(e.hr,{}),`
`,n(e.p,{children:"Een vlotte site voor een snelle zwemmer. Dat is onze bedoeling. Via deze site gaat Guido jullie op de hoogte houden van wedstrijden, trainingen en interessante weetjes en we zijn nog lang niet uitgebouwd !!!!"}),`
`,n(e.ul,{children:[`
`,n(e.li,{children:[`
`,n(e.p,{children:"Veel foto’s"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"Laatste nieuws,"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"Gastenboek,"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"Engelse versie"}),`
`]}),`
`,n(e.li,{children:[`
`,n(e.p,{children:"etc.. etc.."}),`
`]}),`
`]}),`
`,n(e.p,{children:["Houd deze site dus in de gaten !!!",n(e.br,{}),`
We wensen Guido veel succes met de Nederlandse kampioenschappen.`]})]})}function c(t={}){const{wrapper:e}=t.components||{};return e?n(e,{...t,children:n(o,{...t})}):o(t)}const w="src/content/blog/en/website-online/index.mdx",x="/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/website-online/index.mdx",i=(t={})=>c({...t,components:{Fragment:s,...t.components,"astro-image":t.components?.img??r}});i[Symbol.for("mdx-component")]=!0;i[Symbol.for("astro.needsHeadRendering")]=!l.layout;i.moduleId="/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/website-online/index.mdx";export{i as Content,f as __usesAstroImage,i as default,x as file,l as frontmatter,b as getHeadings,w as url};
