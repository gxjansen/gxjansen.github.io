const n="elements/index.mdx",i="otherPages",e="elements",t=`#### Heading example

Here is an example of headings. You can use this heading by the following markdown rules. For example: use \`#\` for heading 1 and use \`######\` for heading 6.

# Heading 1

## Heading 2

### Heading 3

#### Heading 4

##### Heading 5

###### Heading 6

---

### Admonition

This is my own component which is auto-imported in all mdx files. You can use it like:

\`\`\`jsx
<Admonition variant="info">Your text here</Admonition>
\`\`\`

<Admonition variant="tip">
  Admonition \`variant="tip"\`. Use this to provide a cool tip.
</Admonition>

<Admonition variant="caution">
  Admonition \`variant="caution"\`. Use this to warn people of potential issues.
</Admonition>

<Admonition variant="danger">
  Admonition \`variant="danger"\`. Use this to tell people not to do something.
</Admonition>

<Admonition variant="info">
  Admonition \`variant="info"\`. Use this to provide extra secret sauce.
</Admonition>

### Emphasis

The emphasis, aka italics, with *asterisks* or *underscores*.

Strong emphasis, aka bold, with **asterisks** or **underscores**.

The combined emphasis with **asterisks and \\*\\*\\***underscores\\*\\*\\*.

Strikethrough uses two tildes. ~~Scratch this.~~

---

### Link

[I'm an inline-style link](https://www.google.com)

[I'm an inline-style link with title](https://www.google.com)

[I'm a reference-style link](https://www.cosmicthemes.com)

[You can use numbers for reference-style link definitions](https://cosmicthemes.com)

Or leave it empty and use the [link text itself](https://www.webreaper.dev).

example.com (but not on Github, for example).

Some text to show that the reference links can follow later.

---

### Paragraph

Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam nihil enim maxime corporis cumque totam aliquid nam sint inventore optio modi neque laborum officiis necessitatibus, facilis placeat pariatur! Voluptatem, sed harum pariatur adipisci voluptates voluptatum cumque, porro sint minima similique magni perferendis fuga! Optio vel ipsum excepturi tempore reiciendis id quidem? Vel in, doloribus debitis nesciunt fugit sequi magnam accusantium modi neque quis, vitae velit, pariatur harum autem a! Velit impedit atque maiores animi possimus asperiores natus repellendus excepturi sint architecto eligendi non, omnis nihil. Facilis, doloremque illum. Fugit optio laborum minus debitis natus illo perspiciatis corporis voluptatum rerum laboriosam.

---

### Ordered List

1. List item

2. List item

3. List item

4. List item

5. List item

---

### Unordered List

* List item

* List item

* List item

* List item

* List item

---

### Code and Syntax Highlighting

This is an \`Inline code\` sample.

\`\`\`javascript
var s = "JavaScript syntax highlighting";
alert(s);
\`\`\`

\`\`\`python
s = "Python syntax highlighting"
print s
\`\`\`

---

### Blockquote

> This is a blockquote example.

---

### Tables

| Markdown | Less      | Pretty     |
| -------- | --------- | ---------- |
| *Still*  | \`renders\` | **nicely** |
| 1        | 2         | 3          |

There must be at least 3 dashes separating each header cell.
The outer pipes (|) are optional, and you don't need to make the
raw Markdown line up prettily. You can also use inline Markdown.
`,s={title:"Elements",description:"Elements in use on MDX pages",draft:!0},o={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/otherPages/elements/index.mdx",rawData:void 0};export{o as _internal,t as body,i as collection,s as data,n as id,e as slug};
