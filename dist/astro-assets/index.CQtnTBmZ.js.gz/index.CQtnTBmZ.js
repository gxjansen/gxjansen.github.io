import{c as e}from"./Admonition.B1kDTFi5.js";import{F as o,$ as s}from"./keystatic-page.D64z8aiI.js";import"./___vite-browser-external_commonjs-proxy.B2SwpVhP.js";import"./_commonjsHelpers.C4iS2aBk.js";import"./index.zSnisxZ3.js";/* empty css                               */import"./astro/assets-service.CJMMCYvq.js";const c={title:"Interior Painting Services",description:"Details of the interior painting services offered by example company",image:"../interior-painting/living-room.jpg",draft:!1};function f(){return[{depth:4,slug:"our-interior-painting-services-include",text:"Our interior painting services include:"}]}const x=!0;function r(i){const n={h4:"h4",li:"li",p:"p",strong:"strong",ul:"ul",...i.components};return e(o,{children:[e(n.p,{children:`Our paint company is a group of professionals. We don’t stand for cutting\r
corners. We don’t stand for sloppy work. We don’t stand for anything less\r
than the best.`}),`
`,e(n.p,{children:["Don’t sweat the details, ",e(n.strong,{children:"we’ll take care of it."})]}),`
`,e(n.h4,{id:"our-interior-painting-services-include",children:"Our interior painting services include:"}),`
`,e(n.ul,{children:[`
`,e(n.li,{children:"Walls"}),`
`,e(n.li,{children:"Ceilings"}),`
`,e(n.li,{children:"Trim"}),`
`,e(n.li,{children:"Doors"}),`
`,e(n.li,{children:"Cabinets"}),`
`,e(n.li,{children:"Staining"}),`
`,e(n.li,{children:"Wallpaper removal"}),`
`]})]})}function a(i={}){const{wrapper:n}=i.components||{};return n?e(n,{...i,children:e(r,{...i})}):r(i)}const v="src/content/services/interior-painting/index.mdx",b="/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/interior-painting/index.mdx",t=(i={})=>a({...i,components:{Fragment:o,...i.components,"astro-image":i.components?.img??s}});t[Symbol.for("mdx-component")]=!0;t[Symbol.for("astro.needsHeadRendering")]=!c.layout;t.moduleId="/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/interior-painting/index.mdx";export{t as Content,x as __usesAstroImage,t as default,b as file,c as frontmatter,f as getHeadings,v as url};
