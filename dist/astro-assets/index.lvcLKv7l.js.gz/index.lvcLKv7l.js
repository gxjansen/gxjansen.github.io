const i="interior-painting/index.mdx",r="services",s="interior-painting",o=`\r
Our paint company is a group of professionals. We don’t stand for cutting\r
corners. We don’t stand for sloppy work. We don’t stand for anything less\r
than the best.\r
\r
Don't sweat the details, **we'll take care of it.**\r
\r
#### Our interior painting services include:\r
\r
- Walls\r
- Ceilings\r
- Trim\r
- Doors\r
- Cabinets\r
- Staining\r
- Wallpaper removal\r
`,a={title:"Interior Painting Services",description:"Details of the interior painting services offered by example company",image:new Proxy({src:"/astro-assets/living-room.CxII9EMt.jpg",width:1658,height:1080,format:"jpg",fsPath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/interior-painting/living-room.jpg"},{get(e,n,t){return n==="clone"?structuredClone(e):n==="fsPath"?"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/interior-painting/living-room.jpg":e[n]}}),draft:!1},c={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/interior-painting/index.mdx",rawData:void 0};export{c as _internal,o as body,r as collection,a as data,i as id,s as slug};
