const e="terms/index.mdx",t="otherPages",o="terms",r=`\r
_Last updated on Nov 18, 2023_\r
\r
**This is purely for example. Please consult a lawyer for your own terms of use.**\r
\r
## Acceptance of Terms\r
\r
These Terms of Use (the “Terms”) are a binding legal agreement between you and Example LLC (“Example LLC”, “we”, “us”, or “our”). By using our website, you agree to be bound by these Terms. If you do not agree to these Terms, you may not use our website.\r
\r
## Changes to Terms\r
\r
We may change these Terms at any time. If we do so, we will let you know either by posting the modified Terms on the website or through other communications. It is important that you review the Terms whenever we modify them because if you continue to use the website after we have posted modified Terms on the website, you are indicating to us that you agree to be bound by the modified Terms. If you do not agree to be bound by the modified Terms, then you may not use the website anymore. Because our website is evolving over time we may change or discontinue all or any part of the website, at any time and without notice, at our sole discretion.\r
\r
## Privacy Policy\r
\r
We respect your privacy and are committed to protecting your personal information. Our Privacy Policy outlines how we collect, use, and disclose information that can be used to identify you and that you provide to us when you access or use our website. Please read our Privacy Policy carefully: [Privacy Policy](/privacy-policy).\r
\r
## Intellectual Property\r
\r
The website and its original content, features, and functionality are owned by Example LLC and are protected by international copyright.\r
\r
## User Content\r
\r
Our website allows you to post, link, store, share, and otherwise make available certain information, text, graphics, videos, or other material (“User Content”). You are responsible for the User Content that you post on or through the website, including its legality, reliability, and appropriateness.\r
\r
By posting User Content on or through the website, you represent and warrant that: (i) the User Content is yours (you own it) and/or you have the right to use it and the right to grant us the rights and license as provided in these Terms, and (ii) that the posting of your User Content on or through the website does not violate the privacy rights, publicity rights, copyrights, contract rights, or any other rights of any person or entity. We reserve the right to terminate the account of anyone found to be infringing on a copyright.\r
\r
You retain any and all of your rights to any User Content you submit, post, or display on or through the website and you are responsible for protecting those rights. We take no responsibility and assume no liability for User Content you or any third party posts on or through the website. However, by posting User Content using the website you grant us the right and license to use, modify, publicly perform, publicly display, reproduce, and distribute such User Content on and through the website. You agree that this license includes the right for us to make your User Content available to other users of the website, who may also use your User Content subject to these Terms.\r
\r
Example LLC has the right but not the obligation to monitor and edit all User Content provided by users.\r
\r
In addition, User Content found on or through this website are the property of Example LLC or used with permission. You may not distribute, modify, transmit, reuse, download, repost, copy, or use said Content, whether in whole or in part, for commercial purposes or for personal gain, without express advance written permission from us.\r
\r
## Prohibited Uses\r
\r
You may use the website only for lawful purposes and in accordance with these Terms. You agree not to use the website:\r
\r
- In any way that violates any applicable law or regulation (including, without limitation, any laws regarding the export of data or software to and from the US or other countries).\r
- For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way by exposing them to inappropriate content or otherwise.\r
- To transmit, or procure the sending of, any advertising or promotional material, including any “junk mail”, “chain letter”, “spam”, or any other similar solicitation.\r
- To impersonate or attempt to impersonate Example LLC, an Example LLC employee, another user, or any other person or entity (including, without limitation, by using email addresses or screen names associated with any of the foregoing).\r
- To engage in any other conduct that restricts or inhibits anyone’s use or enjoyment of the website, or which, as determined by us, may harm Example LLC or users of the website or expose them to liability.\r
\r
Additionally, you agree not to:\r
\r
- Use the website in any manner that could disable, overburden, damage, or impair the site or interfere with any other party’s use of the website, including their ability to engage in real-time activities through the website.\r
- Use any robot, spider, or other automatic device, process, or means to access the website for any purpose, including monitoring or copying any of the material on the website.\r
- Use any manual process to monitor or copy any of the material on the website or for any other unauthorized purpose without our prior written consent.\r
- Use any device, software, or routine that interferes with the proper working of the website.\r
- Introduce any viruses, trojan horses, worms, logic bombs, or other material that is malicious or technologically harmful.\r
- Attempt to gain unauthorized access to, interfere with, damage, or disrupt any parts of the website, the server on which the website is stored, or any server, computer, or database connected to the website.\r
- Attack the website via a denial-of-service attack or a distributed denial-of-service attack.\r
- Otherwise attempt to interfere with the proper working of the website.\r
\r
## Disclaimer of Warranties\r
\r
You understand that we cannot and do not guarantee or warrant that files available for downloading from the internet or the website will be free of viruses or other destructive code. You are responsible for implementing sufficient procedures and checkpoints to satisfy your particular requirements for anti-virus protection and accuracy of data input and output, and for maintaining a means external to our site for any reconstruction of any lost data. WE WILL NOT BE LIABLE FOR ANY LOSS OR DAMAGE CAUSED BY A DISTRIBUTED DENIAL-OF-SERVICE ATTACK, VIRUSES, OR OTHER TECHNOLOGICALLY HARMFUL MATERIAL THAT MAY INFECT YOUR COMPUTER EQUIPMENT, COMPUTER PROGRAMS, DATA, OR OTHER PROPRIETARY MATERIAL DUE TO YOUR USE OF THE WEBSITE OR ANY SERVICES OR ITEMS OBTAINED THROUGH THE WEBSITE OR TO YOUR DOWNLOADING OF ANY MATERIAL POSTED ON IT, OR ON ANY WEBSITE LINKED TO IT.\r
\r
Your use of the website, its content, and any services or items obtained through the website is at your own risk. The website, its content, and any services or items obtained through the website are provided on an “as is” and “as available” basis, without any warranties of any kind, either express or implied. Neither Example LLC nor any person associated with Example LLC makes any warranty or representation with respect to the completeness, security, reliability, quality, accuracy, or availability of the website. Without limiting the foregoing, neither Example LLC nor anyone associated with Example LLC represents or warrants that the website, its content, or any services or items obtained through the website will be accurate, reliable, error-free, or uninterrupted, that defects will be corrected, that our site or the server that makes it available are free of viruses or other harmful components, or that the website or any services or items obtained through the website will otherwise meet your needs or expectations.\r
\r
## Limitation on Liability\r
\r
In no event will Example LLC, its affiliates, or their licensors, service providers, employees, agents, officers, or directors be liable for damages of any kind, under any legal theory, arising out of or in connection with your use, or inability to use, the website, any websites linked to it, any content on the website or such other websites, including any direct, indirect, special, incidental, consequential, or punitive damages, including but not limited to, personal injury, pain and suffering, emotional distress, loss of revenue, loss of profits, loss of business or anticipated savings, loss of use, loss of goodwill, loss of data, and whether caused by tort (including negligence), breach of contract, or otherwise, even if foreseeable.\r
\r
## Indemnification\r
\r
You agree to defend, indemnify, and hold harmless Example LLC, its affiliates, licensors, and service providers, and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys’ fees) arising out of or relating to your violation of these Terms or your use of the website, including, but not limited to, your User Content, any use of the website’s content, services, and products other than as expressly authorized in these Terms or your use of any information obtained from the website.\r
\r
## Governing Law\r
\r
These Terms shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions.\r
\r
Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect. These Terms constitute the entire agreement between us regarding our website and supersede and replace any prior agreements we might have had between us regarding the website.\r
`,n={title:"Terms of Use",description:"Example terms of use"},i={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/otherPages/terms/index.mdx",rawData:void 0};export{i as _internal,r as body,t as collection,n as data,e as id,o as slug};
