import{c as i}from"./Admonition.B1kDTFi5.js";import{F as c,$ as l}from"./keystatic-page.D64z8aiI.js";import"./___vite-browser-external_commonjs-proxy.B2SwpVhP.js";import"./_commonjsHelpers.C4iS2aBk.js";import"./index.zSnisxZ3.js";/* empty css                               */import"./astro/assets-service.CJMMCYvq.js";const a={title:"Exterior Painting Services",description:"Details of the exterior painting services offered by example company",image:"../exterior-painting/image.jpg",draft:!1};function x(){return[{depth:2,slug:"our-exterior-painting-services",text:"Our exterior painting services"},{depth:3,slug:"surface-preparation",text:"Surface Preparation"},{depth:3,slug:"painting-services",text:"Painting Services"},{depth:3,slug:"specialty-services",text:"Specialty Services"},{depth:3,slug:"restoration-and-repair",text:"Restoration and Repair"},{depth:3,slug:"color-consultation",text:"Color Consultation"},{depth:3,slug:"additional-services",text:"Additional Services"}]}const f=!0;function t(e){const n={h2:"h2",h3:"h3",li:"li",p:"p",strong:"strong",ul:"ul",...e.components};return i(c,{children:[i(n.p,{children:`Our paint company is a group of professionals. We don’t stand for cutting\r
corners. We don’t stand for sloppy work. We don’t stand for anything less\r
than the best.`}),`
`,i(n.p,{children:["Don’t sweat the details, ",i(n.strong,{children:"we’ll take care of it."})]}),`
`,i(n.h2,{id:"our-exterior-painting-services",children:"Our exterior painting services"}),`
`,i(n.h3,{id:"surface-preparation",children:"Surface Preparation"}),`
`,i(n.ul,{children:[`
`,i(n.li,{children:[`
`,i(n.p,{children:"Power washing"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Scraping and sanding"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Caulking and sealing"}),`
`]}),`
`]}),`
`,i(n.h3,{id:"painting-services",children:"Painting Services"}),`
`,i(n.ul,{children:[`
`,i(n.li,{children:[`
`,i(n.p,{children:"Full exterior painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Trim and accent painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Door and window frame painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Fence and deck painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Garage door painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Siding painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Stucco painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Brick painting"}),`
`]}),`
`]}),`
`,i(n.h3,{id:"specialty-services",children:"Specialty Services"}),`
`,i(n.ul,{children:[`
`,i(n.li,{children:[`
`,i(n.p,{children:"Exterior mural painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Faux finishes"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Textured painting"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Weatherproof coatings"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Protective coatings"}),`
`]}),`
`]}),`
`,i(n.h3,{id:"restoration-and-repair",children:"Restoration and Repair"}),`
`,i(n.ul,{children:[`
`,i(n.li,{children:[`
`,i(n.p,{children:"Wood rot repair"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Siding replacement"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Surface repairs"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Patching and filling cracks"}),`
`]}),`
`]}),`
`,i(n.h3,{id:"color-consultation",children:"Color Consultation"}),`
`,i(n.ul,{children:[`
`,i(n.li,{children:[`
`,i(n.p,{children:"Assistance with color selection"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Color matching and coordination"}),`
`]}),`
`]}),`
`,i(n.h3,{id:"additional-services",children:"Additional Services"}),`
`,i(n.ul,{children:[`
`,i(n.li,{children:[`
`,i(n.p,{children:"Pressure washing"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Gutter cleaning and maintenance"}),`
`]}),`
`,i(n.li,{children:[`
`,i(n.p,{children:"Exterior surface cleaning and maintenance"}),`
`]}),`
`]})]})}function o(e={}){const{wrapper:n}=e.components||{};return n?i(n,{...e,children:i(t,{...e})}):t(e)}const v="src/content/services/exterior-painting/index.mdx",S="/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/exterior-painting/index.mdx",r=(e={})=>o({...e,components:{Fragment:c,...e.components,"astro-image":e.components?.img??l}});r[Symbol.for("mdx-component")]=!0;r[Symbol.for("astro.needsHeadRendering")]=!a.layout;r.moduleId="/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/exterior-painting/index.mdx";export{r as Content,f as __usesAstroImage,r as default,S as file,a as frontmatter,x as getHeadings,v as url};
