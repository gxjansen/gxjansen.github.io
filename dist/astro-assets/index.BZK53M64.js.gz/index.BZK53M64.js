const o="en/persuasion-profiling-dawn-of-a-new-marketing-era/index.mdx",n="blog",s="en/persuasion-profiling-dawn-of-a-new-marketing-era",a=`How would you like to know what makes your visitors 'tick' (or in this context: 'click'), even when that visitor never visited your site ever before? What if you wouldn't be limited to creating a website for 'the average visitor' (that probably doesn't exist), but that you're website would automatically adapt itself to every specific visitor? Still not interested? What if I tell you this will increase your conversion rates not by mere percentages, but with twenty or forty percent? Yeah I know this sounds too good to be true. But this reality is getting here sooner then you might think...

**Welcome to a new way of marketing that is called *Persuasion Profiling*.** 

Last week, I had a meeting with a select group (the PersuasionAPI Dream Team ;) ) at [Arjan Haring](http://www.linkedin.com/in/instanthappiness)s place where he told us all about a new service he is building with [Maurits Kaptein](http://www.linkedin.com/in/mauritskaptein) called **PersuasionAPI**. In short, this service does the following:\\\\

1. You create several different variants of parts of your webshop (images or text), much like you would do with a regular A/B test. Each variant aims at a different persuasion technique like [social proof](/post/social-proof/), [scarcity](/post/scarcity/), [authority](/post/authority-figure/) etc. etc..

2. Presenting these variants to your visitors gives PersuasionAPI the ability to learn what persuasion technique gets a visitor (linked to a cookie/ IP-adress) to buy stuff on your site. Because the system can compare behavior of new visitors with existing profiles, it's getting faster and easier to profile new visitors.

3. All this data is gathered into one big database where everyone who joins can get access to already existing profiles. This means you don't have to build all data yourself and you don't need a massive amount of traffic to make this work for you.

4. Visitor behavior isn't fixed but changes over time and visitors might be sensitive to different stimuli on different websites. That is why PersuasionAPI will continually keep testing other persuasion techniques to see what triggers your visitors.

\\
How great would it be to have this tool (or similar) integrated into your (Magento) e-commerce platform? I'll be going to the Magento Developers Paradise at Ibiza next week, You can be sure I'll be asking around to get something like this into Magento 2.0...\\
\\
 
`,r={title:"Persuasion profiling: Dawn of a New Marketing Era",description:"PersuasionAPI: A new tool that makes your website much more persuasive",authors:[{slug:"gxjansen",collection:"authors"}],pubDate:new Date(13066272e5),heroImage:new Proxy({src:"/astro-assets/heroImage.s6SVZi7D.png",width:895,height:412,format:"png",fsPath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/persuasion-profiling-dawn-of-a-new-marketing-era/heroImage.png"},{get(t,e,i){return e==="clone"?structuredClone(t):e==="fsPath"?"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/persuasion-profiling-dawn-of-a-new-marketing-era/heroImage.png":t[e]}}),categories:["tools","Persuasion"],draft:!1},u={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/persuasion-profiling-dawn-of-a-new-marketing-era/index.mdx",rawData:void 0};export{u as _internal,a as body,n as collection,r as data,o as id,s as slug};
