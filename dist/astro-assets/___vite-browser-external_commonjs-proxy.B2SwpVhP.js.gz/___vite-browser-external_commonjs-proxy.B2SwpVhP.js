import{g as e}from"./_commonjsHelpers.C4iS2aBk.js";const t={},r=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(r);export{a as r};
