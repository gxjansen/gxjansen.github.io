const a=new Map;export{a as default};
