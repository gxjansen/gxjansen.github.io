const s="deck-and-fence-staining/index.mdx",i="services",a="deck-and-fence-staining",c=`\r
Why sweat in the summer heat or freeze in the winter cold when you can have\r
your home painted by professionals? We offer deck and fence staining\r
services to help you keep your home looking its best. Our team of\r
professionals will come out and stain your deck or fence with a high\r
quality, long lasting stain that will protect your wood from the elements.\r
`,o={title:"Deck and Fence Staining Services",description:"Details of the deck and fence staining services offered by example company",image:new Proxy({src:"/astro-assets/paint-swatches.9N_9pUY9.jpg",width:1560,height:1080,format:"jpg",fsPath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/deck-and-fence-staining/paint-swatches.jpg"},{get(n,e,t){return e==="clone"?structuredClone(n):e==="fsPath"?"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/deck-and-fence-staining/paint-swatches.jpg":n[e]}}),draft:!1},r={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/services/deck-and-fence-staining/index.mdx",rawData:void 0};export{r as _internal,c as body,i as collection,o as data,s as id,a as slug};
