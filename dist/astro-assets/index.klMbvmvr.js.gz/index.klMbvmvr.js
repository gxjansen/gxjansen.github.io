const a="en/new-domain-and-cms/index.mdx",o="blog",s="en/new-domain-and-cms",i=`I managed to purchase the gui.do domain name (yes, very proud of this nerdy achievement) and switched the website to Grav CMS. I'm quite intrigued by the simplicity and flexibility of a flat file system, and I'm looking forward to see how it will work out.

This also means that after 13 year, I've moved away from hosting my website with Mambo/Joomla!

Last website:

September 2017:

![](../new-domain-and-cms/SCR-20240626-uqpw.png)

Januari 2014:

![](../new-domain-and-cms/SCR-20240627-bndm.png)
`,r={title:"New domain and CMS!",description:"Switched to gui.do and Grav CMS",authors:[{slug:"gxjansen",collection:"authors"}],pubDate:new Date(15071616e5),heroImage:new Proxy({src:"/astro-assets/heroImage.Z6ASCtLe.png",width:2109,height:1264,format:"png",fsPath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/new-domain-and-cms/heroImage.png"},{get(e,n,t){return n==="clone"?structuredClone(e):n==="fsPath"?"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/new-domain-and-cms/heroImage.png":e[n]}}),categories:["Website Update","Archive"],draft:!1},d={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/new-domain-and-cms/index.mdx",rawData:void 0};export{d as _internal,i as body,o as collection,r as data,a as id,s as slug};
