const s="en/website-online/index.mdx",i="blog",o="en/website-online",a=`*Translated from the original Dutch (below), posted on guidojansen.nl by my classmate that had setup the site:*

A smooth site for a fast swimmer. That's our intention. Through this site, Guido will keep you informed about competitions, trainings, and interesting facts, and we're far from finished building it!!!!

* Lots of photos

* Latest news

* Guestbook

* English version

* etc., etc.

So keep an eye on this site!!!\\
We wish Guido lots of success with the Dutch championships.

---

Een vlotte site voor een snelle zwemmer. Dat is onze bedoeling. Via deze site gaat Guido jullie op de hoogte houden van wedstrijden, trainingen en interessante weetjes en we zijn nog lang niet uitgebouwd !!!!

* Veel foto's

* Laatste nieuws,

* Gastenboek,

* Engelse versie

* etc.. etc..

Houd deze site dus in de gaten !!!\\
We wensen Guido veel succes met de Nederlandse kampioenschappen.
`,r={title:"Website Online",description:"My first personal website!",authors:[{slug:"gxjansen",collection:"authors"}],pubDate:new Date(9815904e5),heroImage:new Proxy({src:"/astro-assets/heroImage.BVKScx09.png",width:753,height:584,format:"png",fsPath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/website-online/heroImage.png"},{get(n,e,t){return e==="clone"?structuredClone(n):e==="fsPath"?"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/website-online/heroImage.png":n[e]}}),categories:["Archive","Website Update"],draft:!1},l={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/website-online/index.mdx",rawData:void 0};export{l as _internal,a as body,i as collection,r as data,s as id,o as slug};
