const s=new Map;export{s as default};
