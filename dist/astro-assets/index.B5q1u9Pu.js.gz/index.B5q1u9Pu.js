const o="en/999999999/index.mdx",s="blog",i="en/999999999",a=`Today is a special day! First off, it's the 9th day of the 9th month of the year (20)09 aka 09/09/09. Taking time into account, it's getting even better at 09:09:09 in the morning (and also in the evening for those working with a 12-hour time format).\\
\\
Although this is pretty cool in itself (yes I'm a geek), it's getting even better for me personally: Today is the day I become 9.999 days old!\\
\\
So I'm 9.999 days old, on 09/09/09 on 09:09.\\
\\
That are 9 9's, how is that for a coincidence?
`,r={title:"9.999 on 09.09.09 09:09",description:"Fun coincidence!",authors:[{slug:"gxjansen",collection:"authors"}],pubDate:new Date(12524544e5),heroImage:new Proxy({src:"/astro-assets/heroImage.BFZRNTp3.jpg",width:5706,height:3804,format:"jpg",fsPath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/999999999/heroImage.jpg"},{get(t,e,n){return e==="clone"?structuredClone(t):e==="fsPath"?"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/999999999/heroImage.jpg":t[e]}}),categories:["Archive"],draft:!1},c={type:"content",filePath:"/Users/gxjansen/Documents/GitHub/gxjansen.github.io/src/content/blog/en/999999999/index.mdx",rawData:void 0};export{c as _internal,a as body,s as collection,r as data,o as id,i as slug};
